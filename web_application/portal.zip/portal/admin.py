from django.contrib import admin
from .models import Feedback_Complains

# Register your models here.

admin.site.register(Feedback_Complains)
